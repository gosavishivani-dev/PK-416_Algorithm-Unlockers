from django.apps import AppConfig


class EndpointsConfig(AppConfig):
    name = 'endpoints'
